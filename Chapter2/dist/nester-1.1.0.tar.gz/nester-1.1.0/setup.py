from distutils.core import setup


setup(
	name	    =  'nester',
	version     =  '1.1.0',
	py_modules  =  ['nester'],
	author      =  'Ymc',
	author_email=  'ymc_tjut@163.com',
	url         =  'http://www.headfirstlabs.com',
	description =  'A simple printer of nested lists',
)